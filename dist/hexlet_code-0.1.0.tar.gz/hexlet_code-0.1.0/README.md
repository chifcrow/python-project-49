[![Maintainability](https://api.codeclimate.com/v1/badges/c0c0bd41b3105ab57b32/maintainability)](https://codeclimate.com/github/chifcrow/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/c0c0bd41b3105ab57b32/test_coverage)](https://codeclimate.com/github/chifcrow/python-project-49/test_coverage)
